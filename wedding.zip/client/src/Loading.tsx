// Loading is a component that is displayed while the page is loading.

import React, {Component} from 'react';

export class Loading extends Component<{}, {}> {
	render = (): JSX.Element => {
		return (
			<div>
				<h1>Please Wait Loading...</h1>
			</div>
		)
	}
}
