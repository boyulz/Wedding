import React, { Component, ChangeEvent, MouseEvent } from 'react'
import { GuestInfo, parseGuestInfo } from './GuestInfo'
import { isRecord } from './record'
import { Loading } from './Loading'

type GuestDetailsProps = {
	onBack: () => void
	GuestName: string
}

type GuestDetailsState = {
	Name: string
	GuestDetail: GuestInfo
	IsLoaded: boolean
}

type LoadCallback = (name: string, info: GuestInfo | undefined) => void
type SaveCallback = (name: string, saved: boolean) => void

// Shows a page that allows user to edit guest's info
export class GuestDetails extends Component<GuestDetailsProps, GuestDetailsState> {
	constructor(props: GuestDetailsProps) {
		super(props)

		this.state = {
			Name: '',
			GuestDetail: {
				GuestName: '',
				GuestOf: '',
				Family: false,
				spec: '',
				addition: -1,
				companyGuest: '',
				companySpec: '',
			},
			IsLoaded: false,
		}

		this.doLoadFileClick(props.GuestName, this.doLoadFileResp)
	}
	render = (): JSX.Element => {
		return this.state.IsLoaded? (
			<div>
				<h1>Guest Details</h1>
				<h3>
					{this.state.GuestDetail.GuestName}, guest of {this.state.GuestDetail.GuestOf}, {this.state.GuestDetail.Family === true ? 'Family' : ''}
				</h3>
				<label htmlFor='spec'>Dietary Restrictions: (Specify "none" if none)</label>
				<input type='text' id='spec' value={this.state.GuestDetail.spec} onChange={this.doSpecChange}></input>
				<br />
				<br />
				<label htmlFor='addition'>Additional Guests?</label>
				<select id='addition' value={this.state.GuestDetail.addition} onChange={this.doAdditionChange}>
					<option value='-1'>Unknown</option>
					<option value='0'>0</option>
					<option value='1'>1</option>
				</select>
				<br />
				<br />
				{this.renderAdditionalGuest()}
				<button type='button' onClick={this.doSaveClick}>
					Save
				</button>
				<button type='button' onClick={this.doBackClick}>
					Back
				</button>
			</div>
		): <Loading />
	}

	doSpecChange = (evt: ChangeEvent<HTMLInputElement>): void => {
		this.setState({
			GuestDetail: {
				GuestName: this.state.GuestDetail.GuestName,
				GuestOf: this.state.GuestDetail.GuestOf,
				Family: this.state.GuestDetail.Family,
				spec: evt.target.value,
				addition: this.state.GuestDetail.addition,
				companyGuest: this.state.GuestDetail.companyGuest,
				companySpec: this.state.GuestDetail.companySpec,
			},
		})
	}

	doAdditionChange = (evt: ChangeEvent<HTMLSelectElement>): void => {
		this.setState({
			GuestDetail: {
				GuestName: this.state.GuestDetail.GuestName,
				GuestOf: this.state.GuestDetail.GuestOf,
				Family: this.state.GuestDetail.Family,
				spec: this.state.GuestDetail.spec,
				addition: Number(evt.target.value),
				companyGuest: this.state.GuestDetail.companyGuest,
				companySpec: this.state.GuestDetail.companySpec,
			},
		})
	}

	renderAdditionalGuest = (): JSX.Element => {
		if (this.state.GuestDetail.addition === 0 || this.state.GuestDetail.addition === -1) {
			return <div></div>
		} else {
			return (
				<div>
					<label htmlFor='name'>Name:</label>
					<input type='text' id='name' value={this.state.GuestDetail.companyGuest} onChange={this.doNameChange}></input>
					<br />
					<br />
					<label htmlFor='spec'>Dietary Restrictions: (Specify "none" if none)</label>
					<input type='text' id='spec' value={this.state.GuestDetail.companySpec} onChange={this.doAdditionalSpecChange}></input>
					<br />
					<br />
				</div>
			)
		}
	}

	doNameChange = (evt: ChangeEvent<HTMLInputElement>): void => {
		this.setState({
			GuestDetail: {
				GuestName: this.state.GuestDetail.GuestName,
				GuestOf: this.state.GuestDetail.GuestOf,
				Family: this.state.GuestDetail.Family,
				spec: this.state.GuestDetail.spec,
				addition: this.state.GuestDetail.addition,
				companyGuest: evt.target.value,
				companySpec: this.state.GuestDetail.companySpec,
			},
		})
	}

	doAdditionalSpecChange = (evt: ChangeEvent<HTMLInputElement>): void => {
		this.setState({
			GuestDetail: {
				GuestName: this.state.GuestDetail.GuestName,
				GuestOf: this.state.GuestDetail.GuestOf,
				Family: this.state.GuestDetail.Family,
				spec: this.state.GuestDetail.spec,
				addition: this.state.GuestDetail.addition,
				companyGuest: this.state.GuestDetail.companyGuest,
				companySpec: evt.target.value,
			},
		})
	}

	doSaveClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
		if (this.state.GuestDetail.spec === '') {
			alert("Must specify any dietary restrictions of guest or 'none'")
		}
		if (this.state.GuestDetail.addition === 1) {
			if (this.state.GuestDetail.companyGuest === '') {
				alert("Must give the additional guest's name!")
			} else if (this.state.GuestDetail.companySpec === '') {
				alert("Must specify any dietary restrictions of additional guest or 'none'")
			}
		}
		if (!this.state.GuestDetail.GuestName) {
			alert("Must give the guest's name!")
		}
		this.doSaveFileClick(this.state.GuestDetail.GuestName, this.state.GuestDetail, this.doSaveFileResp)
	}

	doBackClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
		this.props.onBack()
	}

	doLoadFileClick = (name: string, cb: LoadCallback): void => {
		fetch('/api/load?name=' + encodeURIComponent(name))
			.then(res => this.doLoadResp(name, res, cb))
			.catch(() => this.doLoadError('failed to connect to server'))
	}

	doLoadResp = (name: string, res: Response, cb: LoadCallback): void => {
		if (res.status === 200) {
			res.json()
				.then(val => this.doLoadJson(name, val, cb))
				.catch(() => this.doLoadError('200 response is not JSON'))
		} else if (res.status === 400) {
			res.text()
				.then(this.doLoadError)
				.catch(() => this.doLoadError('400 response is not text'))
		} else {
			this.doLoadError(`bad status code: ${res.status}`)
		}
	}

	doLoadJson = (name: string, val: unknown, cb: LoadCallback): void => {
		if (!isRecord(val) || typeof val.name !== 'string' || val.content === undefined) {
			console.error('Invalid JSON from /api/load', val)
			return
		}

		cb(name, parseGuestInfo(val.content))
	}

	doLoadError = (msg: string): void => {
		console.error(`Error fetching /api/load: ${msg}`)
	}

	doLoadFileResp = (name: string, info: GuestInfo | undefined): void => {
		if (info === undefined) {
			this.setState({
				Name: name,
				GuestDetail: {
					GuestName: name,
					GuestOf: '',
					Family: false,
					spec: '',
					addition: -1,
					companyGuest: '',
					companySpec: '',
				},
			})
		} else {
			this.setState({ Name: name, GuestDetail: info, IsLoaded: true })
		}
	}

	doSaveFileClick = (name: string, info: GuestInfo, cb: SaveCallback): void => {
		const body = { name: name, content: info }
		fetch('/api/save', {
			method: 'POST',
			body: JSON.stringify(body),
			headers: { 'Content-Type': 'application/json' },
		})
			.then(res => this.doSaveResp(name, res, cb))
			.catch(() => this.doSaveError('failed to connect to server'))
	}

	doSaveResp = (name: string, res: Response, cb: SaveCallback): void => {
		if (res.status === 200) {
			res.json()
				.then(val => this.doSaveJson(name, val, cb))
				.catch(() => this.doSaveError('200 response is not JSON'))
		} else if (res.status === 400) {
			res.text()
				.then(this.doSaveError)
				.catch(() => this.doSaveError('400 response is not text'))
		} else {
			this.doSaveError(`bad status code: ${res.status}`)
		}
	}

	doSaveFileResp = (_name: string, saved: boolean): void => {
		if (!saved) {
			alert('File unsaved!')
			return
		}
		// no need update this time, how about auto back to list page with a tip ?
		// else {
		//     listFilesOfGusetList(this.doListResp);
		// }
	}

	doSaveError = (msg: string): void => {
		console.error(`Error fetching /api/save: ${msg}`)
	}

	doSaveJson = (name: string, val: unknown, cb: SaveCallback): void => {
		if (!isRecord(val) || typeof val.saved !== 'boolean') {
			console.error('Invalid JSON from /api/save', val)
			return
		}

		cb(name, val.saved)
	}
}
