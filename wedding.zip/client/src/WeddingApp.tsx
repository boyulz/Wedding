import React, { Component, /*ChangeEvent, MouseEvent*/ } from "react";
import { GuestList} from "./GuestList"
import { AddGuest} from "./AddGuest"
import { GuestDetails } from "./GuestDetails";


// TODO: When you're ready to get started, you can remove all the example 
//   code below and start with this blank application:
type Page = {kind: "GuestList"} | {kind: "AddGuest"} | {kind: "GuestDetail"}
// type GuestDetail = {
//   GuestOf: "Molly" | "James" | undefined;
//   Family: boolean;
//   spec: string;
//   addition: 0 | 1 | undefined;
//   companyGuest: string | undefined;
//   companySpec: string | undefined;
// };
type WeddingAppState = {
  PageInfo: Page;
  GuestName: string;
}

/** Displays the UI of the Wedding rsvp application. */
export class WeddingApp extends Component<{}, WeddingAppState> {

  constructor(props: {}) {
    super(props);
    // const defaultGuestDetail: = {
    //   GuestOf: undefined,
    //   Family: false,
    //   spec: "",
    //   addition: undefined,
    //   companyGuest: undefined,
    //   companySpec: undefined
    // };
    this.state = {PageInfo: {kind: "GuestList"}, GuestName: ""};
    
      // listFilesOfGusetList(this.doListResp)
  }
  
  render = (): JSX.Element => {
    if (this.state.PageInfo.kind === "GuestList") {
      return (
        <div>
          <GuestList onAdd={this.doAddClick} onGuestDetail={this.doGuestDetailClick} />
        </div>
      );
    } else if (this.state.PageInfo.kind === "AddGuest"){
      //console.log(this.state.GuestInfo)
      //console.log(this.state.GuestList)
      return (
        <div>
          <AddGuest onBack={this.doBackClick} GuestName={this.state.GuestName}/>
        </div>
      );
    } else {
      return (
        <div>
          <GuestDetails GuestName={this.state.GuestName} onBack={this.doBackClick}/>
        </div>
      );
    }
  };

  // renderError = (): JSX.Element => {
  //   const style = {width: '300px', backgroundColor: 'rgb(246,194,192)',
  //     border: '1px solid rgb(137,66,61)', borderRadius: '5px', padding: '5px' };
  //   if (this.state.GuestInfo.kind === "AddGuest") {
  //     if (this.state.GuestInfo.GuestName.length === 0){
  //       return (
  //         <div style={{marginTop: '15px'}}>
  //           <span style={style}><b>Error</b>: Please enter the Name!</span>
  //       </div>);
  //     } else if (this.state.GuestInfo.GuestOf === undefined){
  //       return (
  //         <div style={{marginTop: '15px'}}>
  //           <span style={style}><b>Error</b>: Please confirm who's guest!</span>
  //         </div>);
  //     } else if (this.state.GuestInfo.Family === undefined){
  //       return (
  //         <div style={{marginTop: '15px'}}>
  //           <span style={style}><b>Error</b>: Please determin if the guest is a family member!</span>
  //       </div>);
  //     } else {
  //       return <div></div>;
  //     }
  //   } else {
  //     return <div></div>;
  //   }
  // };
  doAddClick = (): void => {
    this.setState({PageInfo: {kind: "AddGuest"}});
  }


  // *** only need GuestInfo, GusetName in this Object already
  // doAddGuestClick = (GuestInfo:GuestInfo): void => {
  //   // const newList = this.state.AllGuests.concat(GuestName);
  //   // this.setState({PageInfo: {kind: "GuestList"}, AllGuests: newList});
  //   saveFile(GuestInfo.GuestName, GuestInfo, this.doSaveResp);
  // }

  doBackClick = (): void => {
    this.setState({PageInfo: {kind: "GuestList"}});
  }


  doGuestDetailClick = (name: string): void => {
    // console.log(name)
    this.setState({PageInfo: {kind: "GuestDetail"}, GuestName: name});
    // fetch load api to get details of guest
    // loadFile(name, this.doLoadResp);
  }
}

  // doSaveResp = (_name: string, saved: boolean): void => {
  //   if (!saved) {
  //     alert("File unsaved!");
  //     return;
  //   } else {
  //     listFilesOfGusetList(this.doListResp);
  //   }
  // }

  // doSaveClick = (name: string, info: GuestInfo): void => {    
  //   saveFile(name, info, this.doSaveResp)

  // }

  // doListResp = (names:GuestInfo[]): void => {
  //   this.setState({AllGuests: names})
  // }

  // doOpenFileClick = (name: string): void => {
  //   loadFile(name, this.doLoadResp);
  // }


  // doLoadResp = (name: string, info: GuestInfo|undefined): void => {
  //   if (info === undefined){
  //     this.setState({ GuestName: name, GuestDetail: {GuestName: name, GuestOf: "", Family: false, spec: "",
  //     addition: -1, companyGuest: "", companySpec: ""}})
  //   } else {
  //     this.setState({GuestName: name, GuestDetail: info})
  //   }
  // }

  // doUpdateChange = (info: GuestInfo): void => {
  //   this.setState({GuestDetail: info})
  // }

// type WeddingAppState = {
//   name: string;  // mirror state of name text box
//   msg: string;   // message sent from server
// }


// /** Displays the UI of the Wedding rsvp application. */
// export class WeddingApp extends Component<{}, WeddingAppState> {

//   constructor(props: {}) {
//     super(props);

//     this.state = {name: "", msg: ""};
//   }
  
//   render = (): JSX.Element => {
//     return (<div>
//         <div>
//           <label htmlFor="name">Name:</label>
//           <input type="name" id="name" value={this.state.name}
//                  onChange={this.doNameChange}></input>
//           <button onClick={this.doDummyClick}>Dummy</button>
//         </div>
//         {this.renderMessage()}
//       </div>);
//   };

//   renderMessage = (): JSX.Element => {
//     if (this.state.msg === "") {
//       return <div></div>;
//     } else {
//       return <p>Server says: {this.state.msg}</p>;
//     }
//   };

//   doNameChange = (evt: ChangeEvent<HTMLInputElement>): void => {
//     this.setState({name: evt.target.value, msg: ""});
//   };

//   doDummyClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
//     const name = this.state.name.trim();
//     if (name.length > 0) {
//       const url = "/api/dummy?name=" + encodeURIComponent(name);
//       fetch(url).then(this.doDummyResp)
//           .catch(() => this.doDummyError("failed to connect to server"));
//     }
//   };

//   doDummyResp = (res: Response): void => {
//     if (res.status === 200) {
//       res.json().then(this.doDummyJson)
//           .catch(() => this.doDummyError("200 response is not JSON"));
//     } else if (res.status === 400) {
//       res.text().then(this.doDummyError)
//           .catch(() => this.doDummyError("400 response is not name"));
//     } else {
//       this.doDummyError(`bad status code ${res.status}`);
//     }
//   };

//   doDummyJson = (data: unknown): void => {
//     if (!isRecord(data)) {
//       console.error("200 response is not a record", data);
//       return;
//     }

//     if (typeof data.msg !== "string") {
//       console.error("'msg' field of 200 response is not a string", data.msg);
//       return;
//     }

//     this.setState({msg: data.msg});
//   }

//   doDummyError = (msg: string): void => {
//     console.error(`Error fetching /api/dummy: ${msg}`);
//   }

// }