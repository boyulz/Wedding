import React, { Component, MouseEvent } from 'react'
import { GuestInfo } from './GuestInfo'
import { countMollyFamilyGuests, countMollyGuests } from './GuestCount'
import { countJamesFamilyGuests, countJamesGuests } from './GuestCount'
import { isRecord } from './record'
import { Loading } from './Loading'

type GuestListProps = {
	onAdd: () => void
	onGuestDetail: (name: string) => void
}

type GuestListState = {
	AllGuests: GuestInfo[]
	IsLoaded: boolean
}

type GustListCallback = (GuestList: GuestInfo[]) => void

// Shows a page that tells the user all guests name and summary info
export class GuestList extends Component<GuestListProps, GuestListState> {
	constructor(props: GuestListProps) {
		super(props)
		this.state = { AllGuests: [], IsLoaded: false }
		this.doGusetListClick(this.doListResp)
	}

	render = (): JSX.Element => {
		return this.state.IsLoaded ? (
			<div>
				<h1>Guest List</h1>
				{this.renderNames()}
				<h2>Summary:</h2>
				{this.renderMollySummary()}
				{this.renderJamesSummary()}
				<button type='button' onClick={this.doAddClick}>
					Add Guest
				</button>
			</div>
		) : <Loading />
	}

	renderNames = (): JSX.Element[] => {
		const Guests: JSX.Element[] = []
		for (const Guest of this.state.AllGuests) {
			Guests.push(
				<li key={Guest.GuestName + Math.random()}>
					<a href='#' onClick={evt => this.doGuestDetailClick(evt, Guest.GuestName)}>
						{Guest.GuestName}
					</a>
					&emsp; Guest of {Guest.GuestOf}
					&emsp; {Guest.addition === -1 ? '+1?' : Guest.addition === 1 ? '+1' : Guest.addition === 0 ? '+0' : ''}
				</li>
			)
		}
		return Guests
	}

	renderMollySummary = (): JSX.Element => {
		const MollyGuests: GuestInfo[] = []
		for (const Guest of this.state.AllGuests) {
			if (Guest.GuestOf === 'Molly') {
				MollyGuests.push(Guest)
			}
		}
		if (MollyGuests.length === 0) {
			return (
				<div>
					<h3>0 guest(s) of Molly (0 family)</h3>
				</div>
			)
		} else {
			const Guests = countMollyGuests(this.state.AllGuests)
			const FamilyGuests = countMollyFamilyGuests(this.state.AllGuests)
			if (Guests.min === Guests.max) {
				return (
					<div>
						<h3>
							{Guests.min} guest(s) of Molly ({FamilyGuests} family)
						</h3>
					</div>
				)
			} else {
				return (
					<div>
						<h3>
							{Guests.min} - {Guests.max} guest(s) of Molly ({FamilyGuests} family)
						</h3>
					</div>
				)
			}
		}
	}

	renderJamesSummary = (): JSX.Element => {
		const JamesGuests: GuestInfo[] = []
		for (const Guest of this.state.AllGuests) {
			if (Guest.GuestOf === 'James') {
				JamesGuests.push(Guest)
			}
		}
		if (JamesGuests.length === 0) {
			return (
				<div>
					<h3>0 guest(s) of James (0 family)</h3>
				</div>
			)
		} else {
			const Guests = countJamesGuests(this.state.AllGuests)
			const FamilyGuests = countJamesFamilyGuests(this.state.AllGuests)
			if (Guests.min === Guests.max) {
				return (
					<div>
						<h3>
							{Guests.min} guest(s) of James ({FamilyGuests} family)
						</h3>
					</div>
				)
			} else {
				return (
					<div>
						<h3>
							{Guests.min} - {Guests.max} guest(s) of James ({FamilyGuests} family)
						</h3>
					</div>
				)
			}
		}
	}

	doAddClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
		this.props.onAdd()
	}

	doGuestDetailClick = (evt: MouseEvent<HTMLAnchorElement>, name: string): void => {
		evt.preventDefault()
		//console.log(name)
		console.log(name)
		this.props.onGuestDetail(name)
		// for (const Guest of this.props.AllGuests) {
		//   if (Guest.GuestName === name) {
		//     this.props.onGuestDetail(Guest);
		//   }
		// }
	}

	doListResp = (names: GuestInfo[]): void => {
		this.setState({ AllGuests: names, IsLoaded: true })
	}

	doGusetListClick = (cb: GustListCallback): void => {
		fetch('/api/guestList')
			.then(res => this.doGusetListListResp(res, cb))
			.catch(() => this.doListError('failed to connect to server'))
	}

	doGusetListListResp = (res: Response, cb: GustListCallback): void => {
		if (res.status === 200) {
			res.json()
				.then(val => this.doGusetListJson(val, cb))
				.catch(() => this.doListError('200 response is not JSON'))
		} else if (res.status === 400) {
			res.text()
				.then(this.doListError)
				.catch(() => this.doListError('400 response is not text'))
		} else {
			this.doListError(`bad status code: ${res.status}`)
		}
	}

	doListError = (msg: string): void => {
		console.error(`Error fetching /api/names: ${msg}`)
	}

	doGusetListJson = (val: unknown, cb: GustListCallback): void => {
		if (!isRecord(val) || !Array.isArray(val.list)) {
			console.error('Invalid JSON from /api/guestList', val)
			return
		}

		const list: GuestInfo[] = []
		for (const item of val.list) {
			if (typeof item === 'object') {
				list.push(item)
			} else {
				console.error('Invalid name from /api/guestList', list)
				return
			}
		}

		cb(list)
	}
}
