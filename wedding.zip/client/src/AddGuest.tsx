import React, { Component, ChangeEvent, MouseEvent } from "react";
import { GuestInfo } from "./GuestInfo";
import { isRecord } from "./record";

type AddGuestProps = {
    onBack: () => void;
    GuestName: string;
};

type AddGuestState = {
    GuestInfo: GuestInfo;
    Name: string;
};

type SaveCallback = (name: string, saved: boolean) => void;

// Shows a page that allows user to add guest
export class AddGuest extends Component<AddGuestProps, AddGuestState> {

    constructor(props: AddGuestProps) {
        super(props);

        this.state = {
            Name: props.GuestName, GuestInfo: {
                GuestName: "", GuestOf: "", Family: false, spec: "",
                addition: -1, companyGuest: "", companySpec: ""
            }
        };
    }

    render = (): JSX.Element => {
        //console.log(this.state.GuestInfo)
        return (
            <div>
                <h1>Add Guest</h1>
                <label htmlFor="name">Name:</label>
                <input type="text" id="name" value={this.state.GuestInfo.GuestName}
                    onChange={this.doNameChange}></input><br />
                <p>Guest of:</p>
                <input type="radio" id="molly" name="guest" value="Molly"
                    onChange={this.doMollyClick} />
                <label htmlFor="molly">Molly</label><br />
                <input type="radio" id="james" name="guest" value="James"
                    onChange={this.doJamesClick} />
                <label htmlFor="james">James</label><br /><br />
                <input type="checkbox" id="family" name="family"
                    onChange={this.doFamilyChange} />
                <label htmlFor="family">Family?</label><br /><br />
                <button type="button" onClick={this.doAddGuestClick}>Save</button>
                <button type="button" onClick={this.doBackClick}>Close</button>
                {/* {this.renderError()} */}
            </div>
        )
    }

    doNameChange = (evt: ChangeEvent<HTMLInputElement>): void => {
        this.setState({
            GuestInfo: {
                GuestName: evt.target.value, GuestOf: this.state.GuestInfo.GuestOf, Family: this.state.GuestInfo.Family, spec: this.state.GuestInfo.spec,
                addition: this.state.GuestInfo.addition, companyGuest: this.state.GuestInfo.companyGuest, companySpec: this.state.GuestInfo.companySpec
            }
        });
    }

    doMollyClick = (): void => {
        this.setState({
            GuestInfo: {
                GuestName: this.state.GuestInfo.GuestName, GuestOf: "Molly", Family: this.state.GuestInfo.Family, spec: this.state.GuestInfo.spec,
                addition: this.state.GuestInfo.addition, companyGuest: this.state.GuestInfo.companyGuest, companySpec: this.state.GuestInfo.companySpec
            }
        });
    }

    doJamesClick = (): void => {
        this.setState({
            GuestInfo: {
                GuestName: this.state.GuestInfo.GuestName, GuestOf: "James", Family: this.state.GuestInfo.Family, spec: this.state.GuestInfo.spec,
                addition: this.state.GuestInfo.addition, companyGuest: this.state.GuestInfo.companyGuest, companySpec: this.state.GuestInfo.companySpec
            }
        });
    }

    doFamilyChange = (evt: ChangeEvent<HTMLInputElement>): void => {
        this.setState({
            GuestInfo: {
                GuestName: this.state.GuestInfo.GuestName, GuestOf: this.state.GuestInfo.GuestOf, Family: evt.target.checked, spec: this.state.GuestInfo.spec,
                addition: this.state.GuestInfo.addition, companyGuest: this.state.GuestInfo.companyGuest, companySpec: this.state.GuestInfo.companySpec
            }
        });
    }

    doAddGuestClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
        if (this.state.GuestInfo.GuestName.length === 0) {
            alert("Please enter the guest's name!");
        } else if (this.state.GuestInfo.GuestOf === "") {
            alert("Please confirm who's guest!");
        } else {
            this.doSaveFileClick(this.state.GuestInfo.GuestName, this.state.GuestInfo, this.doSaveFileResp)
        }
    }

    doBackClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
        this.props.onBack();
    }

    doSaveFileClick = (name: string, info: GuestInfo, cb: SaveCallback): void => {
        const body = { name: name, content: info };
        fetch("/api/save", {
            method: 'POST', body: JSON.stringify(body),
            headers: { 'Content-Type': 'application/json' }
        })
            .then((res) => this.doSaveResp(name, res, cb))
            .catch(() => this.doSaveError("failed to connect to server"));
    };

    doSaveResp = (name: string, res: Response, cb: SaveCallback): void => {
        if (res.status === 200) {
            res.json().then((val) => this.doSaveJson(name, val, cb))
                .catch(() => this.doSaveError("200 response is not JSON"));
        } else if (res.status === 400) {
            res.text().then(this.doSaveError)
                .catch(() => this.doSaveError("400 response is not text"));
        } else {
            this.doSaveError(`bad status code: ${res.status}`);
        }
    };

    doSaveFileResp = (_name: string, saved: boolean): void => {
        if (!saved) {
            alert("File unsaved!");
            return;
        } 
        // no need update this time, how about auto back to list page with a tip ?
        // else {
        //     listFilesOfGusetList(this.doListResp);
        // }
    }

    doSaveError = (msg: string): void => {
        console.error(`Error fetching /api/save: ${msg}`);
    };

    doSaveJson = (name: string, val: unknown, cb: SaveCallback): void => {
        if (!isRecord(val) || typeof val.saved !== 'boolean') {
            console.error('Invalid JSON from /api/save', val);
            return;
        }

        cb(name, val.saved);
    };
}