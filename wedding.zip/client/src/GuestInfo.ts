import { isRecord } from "./record";


// Description of an individual auction

export type GuestInfo = {
  readonly GuestName: string;
  readonly GuestOf: string;
  readonly Family: boolean;
  readonly spec: string;
  readonly addition: number;
  readonly companyGuest: string;
  readonly companySpec: string;
};


/**
 * Parses unknown data into an Auction. Will log an error and return undefined
 * if it is not a valid Auction.
 * @param val unknown data to parse into an Auction
 * @return Auction if val is a valid Auction and undefined otherwise
 */
export const parseGuestInfo = (val: unknown): undefined | GuestInfo => {
  if (!isRecord(val)) {
    console.error("not a GuestInfo", val)
    return undefined;
  }

  if (typeof val.GuestName !== "string") {
    console.error("not a GuestInfo: missing 'GuestName'", val)
    return undefined;
  }

  if (typeof val.GuestOf !== "string") {
    console.error("not a GuestInfo: missing 'description'", val)
    return undefined;
  }

  if (typeof val.Family !== "boolean") {
    console.error("not a GuestInfo: missing 'Family'", val)
    return undefined;
  }

  if (typeof val.spec !== "string") {
    console.error("not a GuestInfo: missing or invalid 'spec'", val)
    return undefined;
  }

  if (typeof val.addition !== "number" || val.addition > 1 || isNaN(val.addition) || val.addition < -1) {
    console.error("not a GuestInfo: missing or invalid 'addition'", val)
    return undefined;
  }

  if (typeof val.companyGuest !== "string") {
    console.error("not a GuestInfo: missing or invalid 'companyGuest'", val)
    return undefined;
  }

  if (typeof val.companySpec !== "string") {
    console.error("not a GuestInfo: missing or invalid 'companySpec'", val)
    return undefined;
  }

  return {
    GuestName: val.GuestName, GuestOf: val.GuestOf, Family: val.Family, spec:
    val.spec, addition: val.addition, companyGuest: val.companyGuest, companySpec: val.companySpec
  };
};