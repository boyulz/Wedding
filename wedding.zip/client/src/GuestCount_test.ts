import * as assert from 'assert';
import { GuestInfo } from './GuestInfo';
import { countMollyGuests, countMollyFamilyGuests } from './GuestCount';
import { countJamesGuests, countJamesFamilyGuests } from './GuestCount';

describe('GuestCount', function() {

    it('countMollyGuests', function() {
        const GuestList: GuestInfo[] = [];
        const Guest1: GuestInfo = {GuestName: "zby", GuestOf: "Molly", Family: false, spec: "",
            addition: 0, companyGuest: "", companySpec: ""}
        GuestList.push(Guest1);
        assert.deepStrictEqual(countMollyGuests(GuestList), {min: 1, max: 1})
        const Guest2: GuestInfo = {GuestName: "ycy", GuestOf: "James", Family: true, spec: "",
            addition: -1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest2)
        assert.deepStrictEqual(countMollyGuests(GuestList), {min: 1, max: 1})
        const Guest3: GuestInfo = {GuestName: "zyj", GuestOf: "Molly", Family: true, spec: "",
            addition: -1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest3)
        assert.deepStrictEqual(countMollyGuests(GuestList), {min: 2, max: 3})
        const Guest4: GuestInfo = {GuestName: "ckh", GuestOf: "Molly", Family: true, spec: "",
            addition: 1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest4)
        assert.deepStrictEqual(countMollyGuests(GuestList), {min: 4, max: 5})
    });

    it('countMollyFamilyGuests', function() {
        const GuestList: GuestInfo[] = [];
        const Guest1: GuestInfo = {GuestName: "zby", GuestOf: "Molly", Family: false, spec: "",
            addition: 0, companyGuest: "", companySpec: ""}
        GuestList.push(Guest1);
        assert.deepStrictEqual(countMollyFamilyGuests(GuestList), 0)
        const Guest2: GuestInfo = {GuestName: "ycy", GuestOf: "James", Family: true, spec: "",
            addition: -1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest2)
        assert.deepStrictEqual(countMollyFamilyGuests(GuestList), 0)
        const Guest3: GuestInfo = {GuestName: "zyj", GuestOf: "Molly", Family: true, spec: "",
            addition: -1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest3)
        assert.deepStrictEqual(countMollyFamilyGuests(GuestList), 1)
        const Guest4: GuestInfo = {GuestName: "ckh", GuestOf: "Molly", Family: true, spec: "",
            addition: 1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest4)
        assert.deepStrictEqual(countMollyFamilyGuests(GuestList), 2)
    });

    it('countJamesGuests', function() {
        const GuestList: GuestInfo[] = [];
        const Guest1: GuestInfo = {GuestName: "zby", GuestOf: "James", Family: false, spec: "",
            addition: -1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest1);
        assert.deepStrictEqual(countJamesGuests(GuestList), {min: 1, max: 2})
        const Guest2: GuestInfo = {GuestName: "ycy", GuestOf: "James", Family: true, spec: "",
            addition: -1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest2)
        assert.deepStrictEqual(countJamesGuests(GuestList), {min: 2, max: 4})
        const Guest3: GuestInfo = {GuestName: "zyj", GuestOf: "James", Family: true, spec: "",
            addition: 1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest3)
        assert.deepStrictEqual(countJamesGuests(GuestList), {min: 4, max: 6})
        const Guest4: GuestInfo = {GuestName: "ckh", GuestOf: "Molly", Family: true, spec: "",
            addition: 1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest4)
        assert.deepStrictEqual(countJamesGuests(GuestList), {min: 4, max: 6})
    });

    it('countJamesFamilyGuests', function() {
        const GuestList: GuestInfo[] = [];
        const Guest1: GuestInfo = {GuestName: "zby", GuestOf: "James", Family: false, spec: "",
            addition: 0, companyGuest: "", companySpec: ""}
        GuestList.push(Guest1);
        assert.deepStrictEqual(countJamesFamilyGuests(GuestList), 0)
        const Guest2: GuestInfo = {GuestName: "ycy", GuestOf: "James", Family: true, spec: "",
            addition: -1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest2)
        assert.deepStrictEqual(countJamesFamilyGuests(GuestList), 1)
        const Guest3: GuestInfo = {GuestName: "zyj", GuestOf: "Molly", Family: true, spec: "",
            addition: -1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest3)
        assert.deepStrictEqual(countJamesFamilyGuests(GuestList), 1)
        const Guest4: GuestInfo = {GuestName: "ckh", GuestOf: "James", Family: true, spec: "",
            addition: 1, companyGuest: "", companySpec: ""}
        GuestList.push(Guest4)
        assert.deepStrictEqual(countJamesFamilyGuests(GuestList), 2)
    });
});