import * as assert from 'assert';
import { parseGuestInfo } from './GuestInfo';

describe('GuestCount', function() {

    it('parseGuestInfo', function() {
        const val1 = "test";
        assert.deepStrictEqual(parseGuestInfo(val1), undefined)
        const val2 = {GuestName: 123, GuestOf: "Molly", Family: false, spec: "",
        addition: 0, companyGuest: "", companySpec: ""}
        assert.deepStrictEqual(parseGuestInfo(val2), undefined)
        const val3 = {GuestName: "zby", GuestOf: 123, Family: false, spec: "",
        addition: 0, companyGuest: "", companySpec: ""}
        assert.deepStrictEqual(parseGuestInfo(val3), undefined)
        const val4 = {GuestName: "zby", GuestOf: "Molly", Family: 123, spec: "",
        addition: 0, companyGuest: "", companySpec: ""}
        assert.deepStrictEqual(parseGuestInfo(val4), undefined)
        const val5 = {GuestName: "zby", GuestOf: "Molly", Family: false, spec: 123,
        addition: 0, companyGuest: "", companySpec: ""}
        assert.deepStrictEqual(parseGuestInfo(val5), undefined)
        const val6 = {GuestName: "zby", GuestOf: "Molly", Family: false, spec: "",
        addition: -5, companyGuest: "", companySpec: ""}
        assert.deepStrictEqual(parseGuestInfo(val6), undefined)
        const val7 = {GuestName: "zby", GuestOf: "Molly", Family: false, spec: "",
        addition: 0, companyGuest: 123, companySpec: ""}
        assert.deepStrictEqual(parseGuestInfo(val7), undefined)
        const val8 = {GuestName: "zby", GuestOf: "Molly", Family: false, spec: "",
        addition: 0, companyGuest: "", companySpec: 123}
        assert.deepStrictEqual(parseGuestInfo(val8), undefined)
    });
});