import { GuestInfo } from "./GuestInfo";

/**
 * 
 * @param GuestList A list of guests info
 * @returns Minimum and Maximum Molly's Guests
 */
export const countMollyGuests = (GuestList: GuestInfo[]): {min: number, max: number} => {
    const MollyGuests: GuestInfo[] = [];
    const noAddition: GuestInfo[] = [];
    const haveAddition: GuestInfo[] = [];
    const notSureAddition: GuestInfo[] = [];
    for (const Guest of GuestList){
        if (Guest.GuestOf === "Molly"){
            MollyGuests.push(Guest);
        }
    }
    for (const Guest of MollyGuests) {
        if (Guest.addition === 1){
            haveAddition.push(Guest);
        } else if (Guest.addition === 0){
            noAddition.push(Guest);
        } else {
            notSureAddition.push(Guest);
        }
    }
    const minGuests = 2*haveAddition.length + noAddition.length + notSureAddition.length;
    const maxGuests = 2*haveAddition.length + noAddition.length + 2*notSureAddition.length;
    return {min: minGuests, max: maxGuests};
}

/**
 * 
 * @param GuestList A list of guests info
 * @returns the number of Molly's family guests
 */
export const countMollyFamilyGuests = (GuestList: GuestInfo[]): number => {
    const MollyGuests: GuestInfo[] = [];
    const FamilyGuests: GuestInfo[] = [];
    for (const Guest of GuestList){
        if (Guest.GuestOf === "Molly"){
            MollyGuests.push(Guest);
        }
    }
    for (const Guest of MollyGuests){
        if (Guest.Family === true){
            FamilyGuests.push(Guest);
        }
    }
    return FamilyGuests.length;
}

/**
 * 
 * @param GuestList A list of guests info
 * @returns Minimum and Maximum James's Guests
 */
export const countJamesGuests = (GuestList: GuestInfo[]): {min: number, max: number} => {
    const JamesGuests: GuestInfo[] = [];
    const noAddition: GuestInfo[] = [];
    const haveAddition: GuestInfo[] = [];
    const notSureAddition: GuestInfo[] = [];
    for (const Guest of GuestList){
        if (Guest.GuestOf === "James"){
            JamesGuests.push(Guest);
        }
    }
    for (const Guest of JamesGuests) {
        if (Guest.addition === 1){
            haveAddition.push(Guest);
        } else if (Guest.addition === 0){
            noAddition.push(Guest);
        } else {
            notSureAddition.push(Guest);
        }
    }
    const minGuests = 2*haveAddition.length + noAddition.length + notSureAddition.length;
    const maxGuests = 2*haveAddition.length + noAddition.length + 2*notSureAddition.length;
    return {min: minGuests, max: maxGuests};
}

/**
 * 
 * @param GuestList A list of guests info
 * @returns the number of James's family guests
 */
export const countJamesFamilyGuests = (GuestList: GuestInfo[]): number => {
    const JamesGuests: GuestInfo[] = [];
    const FamilyGuests: GuestInfo[] = [];
    for (const Guest of GuestList){
        if (Guest.GuestOf === "James"){
            JamesGuests.push(Guest);
        }
    }
    for (const Guest of JamesGuests){
        if (Guest.Family === true){
            FamilyGuests.push(Guest);
        }
    }
    return FamilyGuests.length;
}
