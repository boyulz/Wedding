
import * as assert from 'assert';
import { makeSimpleMapMutate } from './map';

describe('map', function() {
    it('contains_key', function() {
        const testMap = makeSimpleMapMutate();
        // Tests for staright line code: 
        assert.strictEqual(testMap.contains_key("a"), false);
        testMap.set_value("a","b");
        assert.strictEqual(testMap.contains_key("a"), true);
        assert.strictEqual(testMap.contains_key("b"), false);
        testMap.set_value("c","d");
        testMap.set_value("e","f");
        testMap.set_value("g","h");
        assert.strictEqual(testMap.contains_key("g"), true);
        assert.strictEqual(testMap.contains_key("e"), true);
        assert.strictEqual(testMap.contains_key("z"), false);
      });
    
    it('get_value', function() {
        const testMap = makeSimpleMapMutate();
        // Tests for staright line code: 
        assert.strictEqual(testMap.get_value("a"), undefined);
        testMap.set_value("a","b");
        assert.strictEqual(testMap.get_value("a"), "b");
        testMap.set_value("c","d");
        testMap.set_value("e","f");
        testMap.set_value("g","h");
        assert.strictEqual(testMap.get_value("g"), "h");
        assert.strictEqual(testMap.get_value("e"), "f");
        assert.strictEqual(testMap.get_value("z"), undefined);
      });

    it('set_value', function() {
        const testMap = makeSimpleMapMutate();
        // Tests for staright line code:
        // first branch when no old pair is replaced
        assert.strictEqual(testMap.set_value("a","b"), false);
        assert.strictEqual(testMap.set_value("c","d"), false);
        assert.strictEqual(testMap.set_value("e","f"), false);

        // second branch when old pair is replaced
        assert.strictEqual(testMap.set_value("a","c"), true);
        assert.strictEqual(testMap.set_value("c","b"), true);
        assert.strictEqual(testMap.set_value("e","z"), true);
      });
    
      it('get_keys', function() {
        const testMap = makeSimpleMapMutate();
        // Straight line code
        testMap.set_value("a","b");
        testMap.set_value("c","d");
        assert.deepStrictEqual(testMap.get_keys(), ["a", "c"]);
        testMap.set_value("e","f");
        testMap.set_value("g","h");
        assert.deepStrictEqual(testMap.get_keys(), ["a", "c", "e", "g"]);
        
      });

      it('clear_map', function() {
        const testMap = makeSimpleMapMutate();
        testMap.set_value("a","b");
        testMap.set_value("c","d");
        testMap.set_value("e","f");
        testMap.set_value("g","h");
        // Straight line code
        testMap.clear_map();
        assert.strictEqual(testMap.contains_key("a"), false);
        assert.strictEqual(testMap.contains_key("c"), false);
        assert.strictEqual(testMap.contains_key("e"), false);
        assert.strictEqual(testMap.contains_key("g"), false);
      });


});