import { Request, Response } from "express";
import { ParamsDictionary } from "express-serve-static-core";
import { MapMutate, makeSimpleMapMutate } from "./map";


// Require type checking of request body.
type SafeRequest = Request<ParamsDictionary, {}, Record<string, unknown>>;
type SafeResponse = Response;  // only writing, so no need to check


const fileMap: MapMutate = makeSimpleMapMutate();

/**
 * Dummy route that just returns a hello message to the client.
 * @param req The request object
 * @param res The response object
 */
export const dummy = (req: SafeRequest, res: SafeResponse): void => {
  const name = first(req.query.name);
  if (name === undefined) {
    res.status(400).send('missing or invalid "name" parameter');
    return;
  }

  res.send({ msg: `Hi, ${name}!` });
};


// Helper to return the (first) value of the parameter if any was given.
// (This is mildly annoying because the client can also give mutiple values,
// in which case, express puts them into an array.)
const first = (param: unknown): string | undefined => {
  if (Array.isArray(param)) {
    return first(param[0]);
  } else if (typeof param === 'string') {
    return param;
  } else {
    return undefined;
  }
};

/**
 * Saves the given name and content for the request and reponse
 * @param req objs for name and content
 * @param res obj will store the name and content
 */
export const save = (req: SafeRequest, res: SafeResponse): void => {
  const name = first(req.body.name);
  if (name === undefined) {
    res.status(400).send('required argument "name" was missing');
    return;
  }
  const value = req.body.content;
  if (value === undefined) {
    res.status(400).send('required argument "value" was missing');
    return;
  }
  fileMap.set_value(name, value)
  res.send({ saved: true });
}


/**
 * Loads previously saved content using given file name
 * @param req obj to load previous file
 * @param res obj will store content of file
 */
export const load = (req: SafeRequest, res: SafeResponse): void => {
  const name = first(req.query.name);
  if (name === undefined) {
    res.status(400).send('required argument "name" was missing');
    return;
  }
  if (!fileMap.contains_key(name)) {
    res.send({ name: name, content: undefined });
  }
  const info = fileMap.get_value(name)
  res.send({ name: name, content: info });
}
/**
* List names that are currently saved
*/
export const guestList = (_req: SafeRequest, res: SafeResponse): void => {
  const filenames = fileMap.get_keys();
  // search all map data return { name, content }
  const data = filenames.map((name) => fileMap.get_value(name))
  res.send({ list: data });
}

/**
 * Reset the mutable map for testing purpose
 */
export const resetForTesting = (): void => {
  fileMap.clear_map();
}
