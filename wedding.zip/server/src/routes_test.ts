
import * as assert from 'assert';
import * as httpMocks from 'node-mocks-http';
import { save, load, resetForTesting, guestList } from './routes';


describe('routes', function() {


  it('save', function() {
    resetForTesting();
    // First branch, straight line code, error case
    const req = httpMocks.createRequest(
        {method: 'POST', url: '/api/save', body: {name: 1086, content: "some stuff"}});
    const res = httpMocks.createResponse();
    save(req, res);

    assert.deepStrictEqual(res._getStatusCode(), 400);
    assert.deepStrictEqual(res._getData(),
        'required argument "name" was missing');

    const req1 = httpMocks.createRequest(
        {method: 'POST', url: '/api/save', body: {content: "some stuff"}});
    const res1 = httpMocks.createResponse();
    save(req1, res1);

    assert.deepStrictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(),
        'required argument "name" was missing');

    // Second branch, straight line code, error case
    const req2 = httpMocks.createRequest(
        {method: 'POST', url: '/api/save', body: {name: "A"}});
    const res2 = httpMocks.createResponse();
    save(req2, res2);

    assert.deepStrictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(),
        'required argument "value" was missing');

    const req3 = httpMocks.createRequest(
        {method: 'POST', url: '/api/save', body: {name: "L"}});
    const res3 = httpMocks.createResponse();
    save(req3, res3);
    
    assert.deepStrictEqual(res3._getStatusCode(), 400);
    assert.deepStrictEqual(res3._getData(),
        'required argument "value" was missing');

    // Third branch, straight line code

    const req4 = httpMocks.createRequest({method: 'POST', url: '/api/save',
        body: {name: "A", content: "some stuff"}});
    const res4 = httpMocks.createResponse();
    save(req4, res4);

    assert.deepStrictEqual(res4._getStatusCode(), 200);
    assert.deepStrictEqual(res4._getData(), {saved: true});

    const req5 = httpMocks.createRequest({method: 'POST', url: '/api/save',
        body: {name: "A", content: "different stuff"}});
    const res5 = httpMocks.createResponse();
    save(req5, res5);

    assert.deepStrictEqual(res5._getStatusCode(), 200);
    assert.deepStrictEqual(res5._getData(), {saved: true});

    // Called to clear all saved transcripts created in this test
    //    to not effect future tests
    resetForTesting();
  });

  it('load', function() {
    resetForTesting();
    // Error 400
    const loadReq0 = httpMocks.createRequest({ method: 'GET', url: '/api/load', query: {} });
    const loadRes0 = httpMocks.createResponse();
    load(loadReq0, loadRes0);
    assert.deepStrictEqual(loadRes0._getStatusCode(), 400);
    assert.deepStrictEqual(loadRes0._getData(), 'required argument "name" was missing');

    // Test for only name no content
    const loadReq1 = httpMocks.createRequest({ method: 'GET', url: '/api/load', query: { name: "nonexistent" } });
    const loadRes1 = httpMocks.createResponse();
    load(loadReq1, loadRes1);
    assert.deepStrictEqual(loadRes1._getStatusCode(), 200);
    assert.deepStrictEqual(loadRes1._getData(), { name: "nonexistent", content: undefined});
    const loadReq2 = httpMocks.createRequest({ method: 'GET', url: '/api/load', query: { name: "onlyname" } });
    const loadRes2 = httpMocks.createResponse();
    load(loadReq2, loadRes2);
    assert.deepStrictEqual(loadRes2._getStatusCode(), 200);
    assert.deepStrictEqual(loadRes2._getData(), { name: "onlyname", content: undefined});

    resetForTesting();
    // Test load for name and content in multi-saves
    const saveReq1 = httpMocks.createRequest({method: 'POST', url: '/api/save',
    body: {name: "zby", content: "by0211"}});
    const saveResp1 = httpMocks.createResponse();
    save(saveReq1, saveResp1);
    const saveReq2 = httpMocks.createRequest({method: 'POST', url: '/api/save',
    body: {name: "ycy", content: "Joey"}});
    const saveResp2 = httpMocks.createResponse();
    save(saveReq2, saveResp2);
    const testloadReq = httpMocks.createRequest(
        {method: 'GET', url: '/api/load', query: {name: "zby"}});
    const testloadRes = httpMocks.createResponse();
    load(testloadReq, testloadRes);
    assert.deepStrictEqual(testloadRes._getStatusCode(), 200);
    assert.deepStrictEqual(testloadRes._getData(), {name: "zby", content: "by0211"});
    const testloadReq1 = httpMocks.createRequest(
        {method: 'GET', url: '/api/load', query: {name: "ycy"}});
    const testloadRes1 = httpMocks.createResponse();
    load(testloadReq1, testloadRes1);
    assert.deepStrictEqual(testloadRes1._getStatusCode(), 200);
    assert.deepStrictEqual(testloadRes1._getData(), {name: "ycy", content: "Joey"});
    resetForTesting();
  });

  it('guestList', function() {
    resetForTesting();
    // Tests for Straight line code (2 in total)
    const req1 = httpMocks.createRequest(
        {method: 'POST', url: '/api/save', body: {name: "Joey", content: "ycy"}}); 
    const res1 = httpMocks.createResponse();
    save(req1, res1);

    const req2 = httpMocks.createRequest(
        {method: 'GET', url: '/api/guestList', query: {}}); 
    const res2 = httpMocks.createResponse();
    guestList(req2, res2);
    assert.deepStrictEqual(res2._getStatusCode(), 200);
    assert.deepStrictEqual(res2._getData(), {list: ["ycy"]});

    const req3 = httpMocks.createRequest(
        {method: 'POST', url: '/api/save', body: {name: "Hins", content: "ckh"}}); 
    const res3 = httpMocks.createResponse();
    save(req3, res3);

    const req4 = httpMocks.createRequest(
        {method: 'GET', url: '/api/guestList', query: {}}); 
    const res4 = httpMocks.createResponse();
    guestList(req4, res4);
    assert.deepStrictEqual(res4._getStatusCode(), 200);
    assert.deepStrictEqual(res4._getData(), {list: ["ycy", "ckh"]});
  });
});
