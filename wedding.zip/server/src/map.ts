/**
 * Represents a mutable map with key-value pairs. 
 */
export interface MapMutate {
    /**
     * Determines if the given key is within a pair in the given list
     * @param x key to determine if list contains
     * @returns true if the map contains the key; false if not
     */
    contains_key: (x: string) => boolean;

    /**
     * Gets the value paired with the first instance of the given key 
     * in the given list
     * @param x key to find the corresponding value for
     * @returns the value corresponding to the x
     * @throws Error when !contains-key(x, L)
     */
    get_value: (x: string) => unknown;

    /**
     * Sets the value paired with the first instance of the given key 
     * in the given list
     * @param x key to find the corresponding value for
     * @param y value to be set
     * @modifies obj
     * @effects obj = obj_0.set(x,y).
     * @returns a boolean indicating if an old value was replaced
     */
    set_value: (x: string, y: unknown) => boolean;

    /**
     * Get all keys in the map
     * @returns an Array<string> containing the keys from all the (key, value) pairs in the map.
     */
    get_keys: () => Array<string>;
    
    /**
     * Clears all pairs from the map
     * @param L list to be cleared
     * @modifies obj
     * @effects obj = obj_0.clear()
     * @returns empty map
     */
    clear_map: () => void;
}

class SimpleMapMutate implements MapMutate{
    // AF: obj = this.map
    private myMap: Map<string, unknown>;
    
    /**
     * Constructs a new instance of the SimpleMapMutate class.
     * @effects Initializes the internal map (`myMap`) to an empty map.
     */
    constructor(){
        this.myMap = new Map();
    }

    contains_key = (x: string): boolean => {
        return this.myMap.has(x);
    }

    get_value = (x: string): unknown =>{
        return this.myMap.get(x);
    }

    set_value = (x: string, y: unknown): boolean =>{
        const ifContains: boolean = this.contains_key(x);
        this.myMap.set(x,y);
        return ifContains;
    }

    get_keys = () : Array<string> => {
        return Array.from(this.myMap.keys());
    }

    clear_map = (): void => {
        this.myMap.clear();
    }
}

/**
 * Creates and returns a new instance of the SimpleMapMutate class.
 * @returns returns a new instance of the SimpleMapMutate class.
 */
export const makeSimpleMapMutate = (): MapMutate => {
    return new SimpleMapMutate();
};